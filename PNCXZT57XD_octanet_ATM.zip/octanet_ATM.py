class Account:
    def __init__(self, user_id, pin):
        self.user_id = user_id
        self.pin = pin
        self.balance = 0
        self.transaction_history = []

    def deposit(self, amount):
        if amount >0:
            self.balance += amount
            self.transaction_history.append(f"Deposited ${amount}")

    def withdraw(self, amount):
        if amount>0 and amount <= self.balance:
            self.balance -= amount
            self.transaction_history.append(f"Withdrew ${amount}")
        else:
            print("Insufficient funds!")

    def transfer(self, amount, recipient):
        if amount >0 and amount <= self.balance:
            self.balance -= amount
            recipient.balance += amount
            self.transaction_history.append(f"Transferred ${amount} to {recipient.user_id}")
            recipient.transcation_history.append(f"Received ${amount} from {self.user_id}")
        else:
            print("Insufficient funds!")
    
    def check_balance(self):
        return self.balance
    
    def view_transaction_history(self):
        return self.transaction_history

class ATM:
    def __init__(self):
        self.accounts={}

    def add_account(self,user_id,pin):
        if user_id not in self.accounts:
            self.accounts[user_id]=Account(user_id,pin)

    def authenticate(self,user_id,pin):
        if user_id in self.accounts and self.accounts[user_id].pin == pin:
            return True 
        return False            

def main():
    atm=ATM()
    # Create User Accounts
    atm.add_account("user123", "1234")
    atm.add_account("user456", "5678")

    while True:
        print("Welcome to the ATM")
        user_id = input("Enter your User ID: ")
        pin = input("Enter your PIN: ")

        if atm.authenticate(user_id,pin):
            user_account = atm.accounts[user_id]

            while True:
                print("\nATM Menu:")
                print("1. Check Balance")
                print("2. Deposit")
                print("3. Withdraw")
                print("4. Transfer")
                print("5.Transcation History")
                print("6. Quit")

                choice = input("Enter your choice: ")

                if choice == "1":
                    print(f"Current Balance: ${user_account.check_balance()}")
                elif choice == "2":
                    amount = float(input("Enter the amount to deposit: $"))
                    user_account.deposit(amount)
                elif choice == "3":
                    amount = float(input("Enter the amount to withdraw: $"))
                    user_account.withdraw(amount)
                elif choice == "4":
                    recipient_id = input("Enter recipient's User ID: ")
                    if recipient_id in atm.accounts:
                        amount = float(input("Enter the amount to transfer: $"))
                        recipient_account=atm.accounts[recipient_id]
                        user_account.transfer(recipient_account,amount)
                    else:
                        print("Recipient not found.")
                elif choice == "5":
                    transactions=user_account.view_transaction_history()
                    for transaction in transactions:
                        print(transaction)
                elif choice == "6":
                    print("Thank you for using the ATM. Goodbye!")
                    break
                else:
                    print("Invalid choice. Please select a valid option.")
            else:
                print("Authentication failed.Please try again..") 
if __name__ == "__main__":
    main()